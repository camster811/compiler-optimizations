#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    int * data;
    int region_a[50];
    int region_b[100];
    data = region_a;
    {
        int source[100] = {0};
        {
            size_t i;
            for (i = 0; i < 100; i++)
            {
                data[i] = source[i];
            }
            printf("%d\n", data[0]);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
