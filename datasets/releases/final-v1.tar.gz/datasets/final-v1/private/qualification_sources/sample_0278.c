#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    int * data;
    int region_a[50];
    int region_b[100];
    data = region_b;
    {
        int source[100] = {0};
        memcpy(data, source, 100*sizeof(int));
        printf("%d\n", data[0]);
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
