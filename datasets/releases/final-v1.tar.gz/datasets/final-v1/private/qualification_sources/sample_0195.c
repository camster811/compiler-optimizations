#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    wchar_t * data;
    wchar_t region_a[50];
    wchar_t region_b[100];
    data = region_b;
    data[0] = L'\0';
    {
        wchar_t * alias = data;
        wchar_t * data = alias;
        {
            wchar_t source[100];
            wmemset(source, L'C', 100-1);
            source[100-1] = L'\0';
            wcscat(data, source);
            wprintf(L"%ls\n", data);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
