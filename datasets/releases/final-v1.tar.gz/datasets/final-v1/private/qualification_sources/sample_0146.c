#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    char * data;
    char region_a[50];
    char region_b[100];
    data = region_a;
    data[0] = '\0';
    {
        char * alias = data;
        char * data = alias;
        {
            char source[100];
            memset(source, 'C', 100-1);
            source[100-1] = '\0';
            strcat(data, source);
            puts(data);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
