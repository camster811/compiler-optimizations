#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#define PAYLOAD L"AAAAAAAAAA"

void copy_payload(void)
{
    wchar_t * data;
    data = NULL;
    data = (wchar_t *)malloc((10+1)*sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
    {
        wchar_t source[10+1] = PAYLOAD;
        memmove(data, source, (wcslen(source) + 1) * sizeof(wchar_t));
        wprintf(L"%ls\n", data);
        free(data);
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
