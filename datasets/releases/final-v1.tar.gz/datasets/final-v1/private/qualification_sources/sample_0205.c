#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#define PAYLOAD L"AAAAAAAAAA"

void copy_payload(void)
{
    wchar_t * data;
    wchar_t region_a[10];
    wchar_t region_b[10+1];
    data = region_a;
    data[0] = L'\0';
    {
        wchar_t * alias = data;
        wchar_t * data = alias;
        {
            wchar_t source[10+1] = PAYLOAD;
            memmove(data, source, (wcslen(source) + 1) * sizeof(wchar_t));
            wprintf(L"%ls\n", data);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
