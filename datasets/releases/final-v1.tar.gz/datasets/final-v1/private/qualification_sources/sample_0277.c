#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#define PAYLOAD "AAAAAAAAAA"

void copy_payload(void)
{
    char * data;
    char region_a[10];
    char region_b[10+1];
    data = region_a;
    data[0] = '\0';
    {
        char * alias = data;
        char * data = alias;
        {
            char source[10+1] = PAYLOAD;
            memmove(data, source, (strlen(source) + 1) * sizeof(char));
            puts(data);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
