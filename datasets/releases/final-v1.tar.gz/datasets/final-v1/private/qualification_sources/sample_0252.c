#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    int64_t * data;
    int64_t region_a[50];
    int64_t region_b[100];
    data = region_a;
    {
        int64_t * alias = data;
        int64_t * data = alias;
        {
            int64_t source[100] = {0};
            {
                size_t i;
                for (i = 0; i < 100; i++)
                {
                    data[i] = source[i];
                }
                printf("%lld\n", (long long)(data[0]));
            }
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
