#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    int64_t * data;
    int64_t region_a[50];
    int64_t region_b[100];
    data = region_b;
    {
        int64_t source[100] = {0};
        memmove(data, source, 100*sizeof(int64_t));
        printf("%lld\n", (long long)(data[0]));
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
