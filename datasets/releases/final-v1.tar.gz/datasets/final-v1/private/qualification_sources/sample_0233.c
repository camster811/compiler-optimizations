#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>

void copy_payload(void)
{
    int * data;
    int * region_a = (int *)__builtin_alloca(50*sizeof(int));
    int * region_b = (int *)__builtin_alloca(100*sizeof(int));
    data = region_b;
    {
        int * alias = data;
        int * data = alias;
        {
            int source[100] = {0};
            memmove(data, source, 100*sizeof(int));
            printf("%d\n", data[0]);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
