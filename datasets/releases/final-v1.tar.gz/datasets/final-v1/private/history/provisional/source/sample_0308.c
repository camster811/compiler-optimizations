#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#define PAYLOAD L"AAAAAAAAAA"

void copy_payload(void)
{
    wchar_t * data;
    wchar_t * region_a = (wchar_t *)__builtin_alloca((10)*sizeof(wchar_t));
    wchar_t * region_b = (wchar_t *)__builtin_alloca((10+1)*sizeof(wchar_t));
    data = region_b;
    data[0] = L'\0';
    {
        wchar_t * alias = data;
        wchar_t * data = alias;
        {
            wchar_t source[10+1] = PAYLOAD;
            wcscpy(data, source);
            wprintf(L"%ls\n", data);
        }
    }
}

int main(void)
{
    copy_payload();
    return 0;
}
